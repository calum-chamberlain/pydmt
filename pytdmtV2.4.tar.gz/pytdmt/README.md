pydmt
=====

Time Domain Moment Tensor Inversion

First README Modify Bpytdmt.py --> pytdmt.py
